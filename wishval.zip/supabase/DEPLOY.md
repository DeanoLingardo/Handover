# Stripe edge functions – deploy guide (adapted to the LIVE schema of project `rmhlnfqgjipeawaddwor`)

Nothing here has been deployed or applied. Both apps share ONE Supabase project; deploy from this (valeter) repo once.
`customer/supabase/functions/booking-extra-charge` is byte-identical to the valeter copy - don't deploy it from both.

## 0. SQL
No migration is required: every column the code uses already exists live (see `optional/20261025_optional_payment_intent_index.sql`,
which is an optional index only). Payment-request state stays inside `booking_messages.content` JSON.

## 1. Secrets (names only; set values in Dashboard -> Edge Functions -> Secrets)
| Secret | Used by | Notes |
|---|---|---|
| `STRIPE_SECRET_KEY` | all four | must start `sk_test_` (test) or `sk_live_`; never a `pk_` key |
| `STRIPE_WEBHOOK_SECRET` | stripe-connect-webhook | signing secret of the **Account** endpoint (`payment_intent.*`) |
| `STRIPE_CONNECT_WEBHOOK_SECRET` | stripe-connect-webhook | signing secret of the **Connect** endpoint (`account.updated`) |
| optional `STRIPE_ALLOW_PLATFORM_HOLD`, `MAX_TIP_PENCE`, `MAX_REQUEST_PENCE`, `MAX_BOOKING_PENCE` | booking-extra-charge | |
`SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` are injected automatically. `BOOKING_PUSH_WEBHOOK_SECRET` (booking-status-push) is unchanged.

## 2. Functions to deploy
| Function | verify_jwt | Replaces live |
|---|---|---|
| `booking-extra-charge` | **true** | v4 (trusted client amount, no caller check) |
| `booking-release-payout` | **true** | v3 (always transferred -> double payout, needed a chat request) |
| `stripe-connect-webhook` | **false** | v10 (one secret; never marked bookings paid) - Stripe sends no JWT |
| `stripe-connect` | **true** | v15 (no country/capabilities) |
Do NOT redeploy `booking-status-push`, `hyper-endpoint`, `public-signup` (live == repo, unchanged).
```
supabase link --project-ref rmhlnfqgjipeawaddwor
supabase functions deploy booking-extra-charge
supabase functions deploy booking-release-payout
supabase functions deploy stripe-connect
supabase functions deploy stripe-connect-webhook --no-verify-jwt
```
Each function folder contains `index.ts` + `handler.ts`; deploy via the CLI so both files are uploaded.

## 3. Stripe webhook endpoints (same URL for both)
`https://rmhlnfqgjipeawaddwor.supabase.co/functions/v1/stripe-connect-webhook`
* Endpoint A "Events on your account": `payment_intent.succeeded`, `payment_intent.payment_failed` -> `STRIPE_WEBHOOK_SECRET`
* Endpoint B "Events on Connected accounts": `account.updated` -> `STRIPE_CONNECT_WEBHOOK_SECRET`
Test and live mode have separate keys/endpoints/secrets.

## 4. App config
Customer app: `EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...` (same Stripe account/mode as the secret key).

## 5. Test
`cd stripe-test && npm install && npm test` (offline, 55 tests), then `node e2e-test-mode.mjs` (test key only), then one phone pass.
Valeter test accounts must finish Stripe Connect onboarding (test data) - otherwise payments fall back to platform hold.
