/**
 * Supabase Edge Function entrypoint: booking-release-payout (logic in ./handler.ts).
 * Deploy: supabase functions deploy booking-release-payout     (JWT verification ON)
 */
import { createClient } from 'npm:@supabase/supabase-js@2';
import Stripe from 'npm:stripe@16.12.0';
import { handleRequest } from './handler.ts';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? '';
const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
const STRIPE_SECRET_KEY = Deno.env.get('STRIPE_SECRET_KEY') ?? '';

const db = createClient(SUPABASE_URL, SERVICE_ROLE);
const stripe = new Stripe(STRIPE_SECRET_KEY || 'sk_missing', { apiVersion: '2024-06-20' });

Deno.serve((req) => {
  if (!SUPABASE_URL || !SERVICE_ROLE || !STRIPE_SECRET_KEY) {
    return new Response(JSON.stringify({ error: 'Missing function environment variables.' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
    });
  }
  return handleRequest(req, {
    env: { stripeSecretKey: STRIPE_SECRET_KEY },
    getUser: async (token) => {
      const { data, error } = await db.auth.getUser(token);
      return error || !data?.user ? null : { id: data.user.id };
    },
    db,
    stripe,
  });
});
