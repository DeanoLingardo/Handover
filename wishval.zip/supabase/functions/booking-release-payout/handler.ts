/**
 * booking-release-payout: called by the valeter app when a job is marked completed.
 *
 * Exactly ONE mechanism pays the valeter for each PaymentIntent:
 *   - destination charge (metadata.payout_mode = 'destination' / PaymentIntent.transfer_data set):
 *       Stripe already moved the valeter's share to their connected account when the charge succeeded.
 *       This function does NOT create a transfer; it just reports the existing transfer (charge.transfer)
 *       and marks the payment-request message as released.
 *   - platform hold (no transfer_data): funds are on the platform balance, so ONE transfer is made
 *       (source_transaction = the charge, idempotency key release:<pi>) for amount - platform fee.
 *
 * Works for main bookings (no payment_request message: PaymentIntent is found via
 * bookings.payment_intent_id, or a Stripe metadata search) AND for chat payment requests.
 */

export type Deps = {
  env: { stripeSecretKey: string };
  getUser: (token: string) => Promise<{ id: string } | null>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  db: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  stripe: any;
  now?: () => number;
};

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(status: number, body: Record<string, unknown>) {
  return new Response(JSON.stringify(body), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });
}

class HttpError extends Error {
  status: number;
  code: string;
  constructor(status: number, message: string, code: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

function safeParse(content: unknown): Record<string, any> | null {
  if (typeof content !== 'string' || !content) return null;
  try {
    const v = JSON.parse(content);
    return v && typeof v === 'object' ? v : null;
  } catch {
    return null;
  }
}

type Item = {
  paymentIntentId: string;
  messageId: string | null;
  messageContent: Record<string, any> | null;
};

type Result = {
  paymentIntentId: string;
  transferId: string | null;
  amount: number; // pence paid to the valeter
  mode: 'destination' | 'platform_hold';
  alreadyReleased: boolean;
};

export async function handleRequest(req: Request, deps: Deps): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json(405, { error: 'Method not allowed' });
  const { db, stripe, env } = deps;
  if (!env.stripeSecretKey) return json(500, { error: 'Missing function environment variables.' });

  try {
    const token = (req.headers.get('Authorization') ?? '').replace(/^Bearer\s+/i, '').trim();
    if (!token) throw new HttpError(401, 'Unauthorized', 'unauthorized');
    const user = await deps.getUser(token);
    if (!user?.id) throw new HttpError(401, 'Unauthorized', 'unauthorized');
    const callerId = String(user.id);

    const body = (await req.json().catch(() => ({}))) as Record<string, any>;
    const bookingId = typeof body?.bookingId === 'string' ? body.bookingId.trim() : '';
    if (!bookingId) throw new HttpError(400, 'bookingId is required.', 'bad_request');

    const { data: booking, error: bookingErr } = await db.from('bookings').select('*').eq('id', bookingId).maybeSingle();
    if (bookingErr || !booking) throw new HttpError(404, 'Booking not found.', 'booking_not_found');

    // caller must be the assigned valeter, or a user of the business (organization) that owns the booking
    let isProvider = String(booking.valeter_id || '') === callerId;
    if (!isProvider && booking.location_id) {
      // live schema: bookings has no organization_id; business bookings link via location_id -> car_wash_locations
      const { data: loc } = await db.from('car_wash_locations').select('organization_id').eq('id', booking.location_id).maybeSingle();
      const orgId = loc?.organization_id ? String(loc.organization_id) : '';
      if (orgId) {
        const { data: prof } = await db.from('profiles').select('organization_id').eq('id', callerId).maybeSingle();
        const { data: org } = await db.from('organizations').select('owner_user_id').eq('id', orgId).maybeSingle();
        isProvider =
          (!!prof?.organization_id && String(prof.organization_id) === orgId) || String(org?.owner_user_id || '') === callerId;
      }
    }
    if (!isProvider) throw new HttpError(403, 'Only the assigned valeter can release this payout.', 'forbidden');

    if (String(booking.status || '') !== 'completed') {
      throw new HttpError(409, 'Payout can only be released after the job is completed.', 'not_completed');
    }

    // ---- collect payments to settle: main booking PI + chat payment requests -----------------
    const items: Item[] = [];
    const seen = new Set<string>();

    let mainPiId = String(booking.payment_intent_id || '');
    if (!mainPiId) {
      try {
        const res = await stripe.paymentIntents.search({
          query: `metadata['booking_id']:'${String(booking.id).replace(/'/g, '')}' AND status:'succeeded'`,
          limit: 20,
        });
        const hit = (res?.data ?? []).find((p: any) => p.metadata?.source === 'booking_payment' && !p.metadata?.request_message_id);
        if (hit) mainPiId = hit.id;
      } catch (e: any) {
        console.warn('[booking-release-payout] PaymentIntent search failed', e?.message);
      }
    }
    if (mainPiId) {
      items.push({ paymentIntentId: mainPiId, messageId: null, messageContent: null });
      seen.add(mainPiId);
    }

    const { data: messages } = await db
      .from('booking_messages')
      .select('id, content, created_at')
      .eq('booking_id', bookingId)
      .eq('message_type', 'payment_request')
      .order('created_at', { ascending: true });
    for (const m of messages ?? []) {
      const content = safeParse(m.content);
      const piId = String(content?.paymentIntentId || '');
      if (!content || content.kind !== 'booking_payment_request' || !piId || seen.has(piId)) continue;
      items.push({ paymentIntentId: piId, messageId: String(m.id), messageContent: content });
      seen.add(piId);
    }

    // ---- settle each ----------------------------------------------------------------------------
    const results: Result[] = [];
    let sawUnpaid = false;
    for (const item of items) {
      const pi = await stripe.paymentIntents.retrieve(item.paymentIntentId, { expand: ['latest_charge'] });
      if (pi.status !== 'succeeded') {
        sawUnpaid = true;
        continue;
      }
      if (pi.metadata?.booking_id && String(pi.metadata.booking_id) !== String(booking.id)) continue; // safety
      const charge = typeof pi.latest_charge === 'object' && pi.latest_charge ? pi.latest_charge : null;
      const chargeId = charge?.id ?? (typeof pi.latest_charge === 'string' ? pi.latest_charge : null);
      const feePence = Number(pi.metadata?.platform_fee_pence ?? pi.application_fee_amount ?? 0) || 0;
      let result: Result;

      if (pi.transfer_data?.destination) {
        // Destination charge: Stripe already paid the connected account. NEVER transfer again.
        const t = charge?.transfer;
        result = {
          paymentIntentId: pi.id,
          transferId: t ? (typeof t === 'string' ? t : t.id) : null,
          amount: Math.max(0, pi.amount - feePence),
          mode: 'destination',
          alreadyReleased: true,
        };
      } else if (pi.metadata?.payout_transfer_id) {
        result = {
          paymentIntentId: pi.id,
          transferId: String(pi.metadata.payout_transfer_id),
          amount: Math.max(0, pi.amount - feePence),
          mode: 'platform_hold',
          alreadyReleased: true,
        };
      } else {
        if (!chargeId) throw new HttpError(409, 'Payment has no charge yet.', 'payment_not_completed');
        if (charge && Number(charge.amount_refunded) > 0) {
          throw new HttpError(409, 'This payment was refunded; payout not released.', 'refunded');
        }
        let destination = String(pi.metadata?.destination_account || '');
        if (!destination) {
          const { data: prof } = await db.from('profiles').select('stripe_account_id').eq('id', booking.valeter_id).maybeSingle();
          destination = String(prof?.stripe_account_id || '');
          if (!destination) {
            // live schema keeps a copy on valeter_profiles (keyed by user_id)
            const { data: vp } = await db.from('valeter_profiles').select('stripe_account_id').eq('user_id', booking.valeter_id).maybeSingle();
            destination = String(vp?.stripe_account_id || '');
          }
        }
        if (!destination) {
          throw new HttpError(409, 'No connected Stripe account found for the valeter.', 'no_connected_account');
        }
        const amount = pi.amount - feePence;
        if (amount <= 0) throw new HttpError(400, 'Valeter payout amount is invalid.', 'invalid_amount');
        const transfer = await stripe.transfers.create(
          {
            amount,
            currency: pi.currency,
            destination,
            source_transaction: chargeId,
            transfer_group: pi.transfer_group || `booking_${booking.id}`,
            metadata: { booking_id: String(booking.id), payment_intent_id: pi.id, payout_kind: 'platform_hold_release' },
          },
          { idempotencyKey: `release:${pi.id}` },
        );
        try {
          await stripe.paymentIntents.update(pi.id, { metadata: { payout_transfer_id: transfer.id } });
        } catch (e: any) {
          console.warn('[booking-release-payout] could not tag PaymentIntent with transfer id', e?.message);
        }
        result = { paymentIntentId: pi.id, transferId: transfer.id, amount, mode: 'platform_hold', alreadyReleased: false };
      }
      results.push(result);

      if (item.messageId && item.messageContent) {
        const next = {
          ...item.messageContent,
          status: 'paid',
          paidAt: item.messageContent.paidAt ?? new Date(deps.now?.() ?? Date.now()).toISOString(),
          payoutStatus: 'released',
          payoutReleasedAt: item.messageContent.payoutReleasedAt ?? new Date(deps.now?.() ?? Date.now()).toISOString(),
          stripeTransferId: result.transferId ?? item.messageContent.stripeTransferId ?? null,
          paymentMode: result.mode,
        };
        const { error } = await db.from('booking_messages').update({ content: JSON.stringify(next) }).eq('id', item.messageId);
        if (error) console.warn('[booking-release-payout] could not update message', error.message);
      }
    }

    if (results.length === 0) {
      throw new HttpError(
        409,
        sawUnpaid ? 'Payment has not completed yet.' : 'No completed payment found for this booking.',
        'payment_not_completed',
      );
    }
    const first = results.find((r) => r.transferId) ?? null;
    if (!first) throw new HttpError(409, 'Payment succeeded but no transfer to the valeter was found yet.', 'transfer_pending');

    return json(200, {
      ok: true,
      transferId: first.transferId,
      amount: results.reduce((s, r) => s + r.amount, 0), // pence
      currency: 'gbp',
      alreadyReleased: results.every((r) => r.alreadyReleased),
      transfers: results,
    });
  } catch (e: any) {
    if (e instanceof HttpError) return json(e.status, { error: e.message, code: e.code });
    console.error('[booking-release-payout]', e?.type || '', e?.message || e);
    const isStripe = typeof e?.type === 'string' && e.type.startsWith('Stripe');
    return json(isStripe ? 502 : 500, {
      error: isStripe ? `Stripe error: ${e.message}` : 'Unexpected server error.',
      code: isStripe ? 'stripe_error' : 'server_error',
    });
  }
}
