/**
 * booking-extra-charge: request handler (dependency-injected so it can be unit tested
 * offline with mocked Stripe + Supabase; see stripe-test/).
 *
 * ONE function for all three customer payments:
 *   (a) main booking payment      -> body { action, bookingId, purpose?: 'booking' }
 *                                    amount is ALWAYS computed from bookings.price (DB), never from the client
 *   (b) chat payment request      -> body { action, bookingId, requestMessageId }
 *                                    amount/fee come from the stored payment_request message
 *   (c) tip                       -> body { action, bookingId, purpose: 'tip', amount (pence) }
 *                                    amount from the client but validated (positive integer pence, max, booking completed)
 *
 * Payment model (single mechanism): Stripe Connect DESTINATION CHARGE.
 *   PaymentIntent has transfer_data.destination (+ application_fee_amount) -> Stripe pays the
 *   valeter/business connected account itself. booking-release-payout must NOT transfer again.
 *   If the recipient has no charges/payouts-enabled Connect account yet, main + request payments fall back to
 *   "platform_hold": charge sits on the platform balance (metadata.payout_mode = 'platform_hold') and
 *   booking-release-payout later makes exactly ONE transfer (source_transaction) after completion.
 *   Tips never fall back (they require a destination).
 *
 * Caller is always authenticated via the JWT (auth.getUser) and must own the booking (bookings.user_id).
 */

export type Env = {
  stripeSecretKey: string;
  /** default true. Set STRIPE_ALLOW_PLATFORM_HOLD=false to refuse payments when the recipient is not payout-ready. */
  allowPlatformHold?: boolean;
  /** pence */ maxTipPence?: number;
  /** pence */ maxRequestPence?: number;
  /** pence */ maxBookingPence?: number;
};

export type Deps = {
  env: Env;
  getUser: (token: string) => Promise<{ id: string } | null>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  db: any; // supabase-js client (service role) or a test double
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  stripe: any; // Stripe client or a test double
  now?: () => number;
};

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

export const MIN_CHARGE_PENCE = 50; // Stripe GBP minimum
export const DEFAULT_MAX_TIP_PENCE = 10_000; // £100
export const DEFAULT_MAX_REQUEST_PENCE = 50_000; // £500
export const DEFAULT_MAX_BOOKING_PENCE = 500_000; // £5,000 sanity cap on DB price

// booking_status enum values in the live DB: scheduled,in_progress,completed,cancelled,pending,confirmed,valeter_assigned,
// en_route,arrived,pending_valeter_acceptance,valeter_declined,valeter_timeout,pending_payment,payment_timeout
const UNPAYABLE_STATUSES = new Set(['cancelled', 'completed', 'valeter_declined', 'valeter_timeout', 'payment_timeout']);

function json(status: number, body: Record<string, unknown>) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json' },
  });
}

class HttpError extends Error {
  status: number;
  code: string;
  constructor(status: number, message: string, code = 'error') {
    super(message);
    this.status = status;
    this.code = code;
  }
}

/** pounds (number|string) -> integer pence, or 0 when invalid. */
export function toPence(value: unknown): number {
  const n = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(n) || n <= 0) return 0;
  return Math.round(n * 100);
}

function safeParse(content: unknown): Record<string, any> | null {
  if (typeof content !== 'string' || !content) return null;
  try {
    const v = JSON.parse(content);
    return v && typeof v === 'object' ? (v as Record<string, any>) : null;
  } catch {
    return null;
  }
}

/**
 * Live schema: stripe_account_id lives on BOTH profiles and valeter_profiles (profiles is what stripe-connect
 * writes; valeter_profiles is kept as a fallback). valeter_profiles is keyed by user_id.
 */
async function stripeAccountForUser(db: any, userId: string): Promise<string | null> {
  if (!userId) return null;
  const { data: p } = await db.from('profiles').select('stripe_account_id').eq('id', userId).maybeSingle();
  if (p?.stripe_account_id) return String(p.stripe_account_id);
  const { data: v } = await db.from('valeter_profiles').select('stripe_account_id').eq('user_id', userId).maybeSingle();
  if (v?.stripe_account_id) return String(v.stripe_account_id);
  return null;
}

async function resolveRecipientAccountId(db: any, booking: Record<string, any>): Promise<string | null> {
  // 1. business / wash-hub bookings (bookings.location_id -> car_wash_locations.organization_id; there is no
  //    bookings.organization_id column in the live DB) -> business profile, then the organization owner
  const locationId = String(booking.location_id || '');
  if (locationId) {
    const { data: loc } = await db.from('car_wash_locations').select('organization_id').eq('id', locationId).maybeSingle();
    const organizationId = loc?.organization_id ? String(loc.organization_id) : '';
    if (organizationId) {
      const { data: biz } = await db
        .from('profiles')
        .select('id, stripe_account_id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'organization')
        .maybeSingle();
      if (biz?.stripe_account_id) return String(biz.stripe_account_id);

      const { data: org } = await db.from('organizations').select('owner_user_id').eq('id', organizationId).maybeSingle();
      const viaOwner = await stripeAccountForUser(db, String(org?.owner_user_id || ''));
      if (viaOwner) return viaOwner;
    }
  }
  // 2. independent valeter
  return stripeAccountForUser(db, String(booking.valeter_id || ''));
}

async function accountIsPayoutReady(stripe: any, accountId: string): Promise<boolean> {
  try {
    const acct = await stripe.accounts.retrieve(accountId);
    return !!(acct && acct.charges_enabled && acct.payouts_enabled);
  } catch {
    return false;
  }
}

async function platformFeeFromContext(db: any, booking: Record<string, any>, amountPence: number): Promise<number> {
  const context = booking.platform_fee_context;
  if (!context) return 0;
  const { data } = await db.from('waw_platform_fees').select('percent').eq('context', context).maybeSingle();
  const pct = Number(data?.percent);
  if (Number.isFinite(pct) && pct >= 0) return Math.round((amountPence * pct) / 100);
  return 0;
}

export async function handleRequest(req: Request, deps: Deps): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json(405, { error: 'Method not allowed' });

  const { env, db, stripe } = deps;
  if (!env.stripeSecretKey || !env.stripeSecretKey.startsWith('sk_')) {
    return json(500, { error: 'STRIPE_SECRET_KEY must be set to a Stripe secret key (sk_...).' });
  }

  try {
    // ---- 1. authenticate caller via JWT -------------------------------------------------------
    const token = (req.headers.get('Authorization') ?? '').replace(/^Bearer\s+/i, '').trim();
    if (!token) throw new HttpError(401, 'Unauthorized', 'unauthorized');
    const user = await deps.getUser(token);
    if (!user?.id) throw new HttpError(401, 'Unauthorized', 'unauthorized');
    const callerId = String(user.id);

    // ---- 2. parse body ------------------------------------------------------------------------
    const body = (await req.json().catch(() => ({}))) as Record<string, any>;
    if (body?.action !== 'create_payment_intent') throw new HttpError(400, 'Unsupported action', 'bad_request');
    const bookingId = typeof body.bookingId === 'string' ? body.bookingId.trim() : '';
    if (!bookingId) throw new HttpError(400, 'bookingId is required', 'bad_request');
    const requestMessageId = typeof body.requestMessageId === 'string' ? body.requestMessageId.trim() : '';

    // ---- 3. load booking + ownership (customerId from the client is ignored) -------------------
    const { data: booking, error: bookingErr } = await db.from('bookings').select('*').eq('id', bookingId).maybeSingle();
    if (bookingErr || !booking) throw new HttpError(404, 'Booking not found', 'booking_not_found');
    if (String(booking.user_id || '') !== callerId) {
      throw new HttpError(403, 'Only the booking customer can pay for this booking', 'forbidden');
    }
    const status = String(booking.status || '');

    // ---- 4. work out what is being paid -------------------------------------------------------
    type Purpose = 'booking' | 'request' | 'tip';
    let purpose: Purpose;
    if (requestMessageId) purpose = 'request';
    else if (body.purpose === 'tip') purpose = 'tip';
    else if (body.purpose === 'booking') purpose = 'booking';
    else if (body.purpose === undefined || body.purpose === null) {
      // Back-compat with app builds that did not send `purpose`: a completed booking + an amount = tip.
      purpose = status === 'completed' && body.amount !== undefined ? 'tip' : 'booking';
    } else throw new HttpError(400, 'Invalid purpose', 'bad_request');

    let amountPence = 0;
    let feePence = 0;
    let description = '';
    let source = '';
    let requestPayload: Record<string, any> | null = null;
    const currency = 'gbp';

    if (purpose === 'booking') {
      if (booking.payment_completed_at) throw new HttpError(409, 'This booking has already been paid', 'already_paid');
      if (UNPAYABLE_STATUSES.has(status)) {
        throw new HttpError(409, `Booking cannot be paid in status "${status}"`, 'invalid_status');
      }
      // Amount ALWAYS from the database. body.amount / body.currency / body.customerId are ignored.
      amountPence = toPence(booking.price);
      const max = env.maxBookingPence ?? DEFAULT_MAX_BOOKING_PENCE;
      if (amountPence < MIN_CHARGE_PENCE || amountPence > max) {
        throw new HttpError(400, 'Booking price is invalid', 'invalid_amount');
      }
      feePence = toPence(booking.platform_fee_amount);
      if (!feePence) feePence = await platformFeeFromContext(db, booking, amountPence);
      description = `Wish a Wash booking ${booking.id}`;
      source = 'booking_payment';
    } else if (purpose === 'request') {
      const { data: msg, error: msgErr } = await db
        .from('booking_messages')
        .select('id, booking_id, sender_id, sender_role, message_type, content')
        .eq('id', requestMessageId)
        .eq('booking_id', bookingId)
        .maybeSingle();
      if (msgErr || !msg) throw new HttpError(404, 'Payment request not found', 'request_not_found');
      if (String(msg.message_type) !== 'payment_request') throw new HttpError(400, 'Message is not a payment request', 'bad_request');
      // A customer must not be able to write their own payment request and pay it.
      if (String(msg.sender_id) === callerId || String(msg.sender_role) === 'customer') {
        throw new HttpError(403, 'Payment requests must come from the valeter or business', 'forbidden');
      }
      requestPayload = safeParse(msg.content);
      if (!requestPayload || requestPayload.kind !== 'booking_payment_request') {
        throw new HttpError(400, 'Payment request payload is invalid', 'bad_request');
      }
      const reqStatus = String(requestPayload.status || 'pending');
      if (reqStatus === 'paid') throw new HttpError(409, 'This request has already been paid', 'already_paid');
      if (reqStatus !== 'pending' && reqStatus !== 'failed') {
        throw new HttpError(409, `Payment request is ${reqStatus}`, 'invalid_status');
      }
      if (status === 'cancelled') throw new HttpError(409, 'Booking is cancelled', 'invalid_status');
      amountPence = toPence(requestPayload.amount);
      const max = env.maxRequestPence ?? DEFAULT_MAX_REQUEST_PENCE;
      if (amountPence < MIN_CHARGE_PENCE || amountPence > max) {
        throw new HttpError(400, 'Payment request amount is invalid', 'invalid_amount');
      }
      if (requestPayload.platformFee !== undefined && requestPayload.platformFee !== null &&
          Number.isFinite(Number(requestPayload.platformFee)) && Number(requestPayload.platformFee) >= 0) {
        feePence = Math.round(Number(requestPayload.platformFee) * 100);
      } else {
        feePence = await platformFeeFromContext(db, booking, amountPence);
      }
      description = String(requestPayload.reason || `Wish a Wash extra charge ${booking.id}`).slice(0, 200);
      source = 'booking_message';
    } else {
      // tip
      if (status !== 'completed') throw new HttpError(409, 'Tips can only be paid once the job is completed', 'invalid_status');
      const raw = body.amount;
      if (typeof raw !== 'number' || !Number.isInteger(raw) || raw <= 0) {
        throw new HttpError(400, 'Tip amount must be a positive whole number of pence', 'invalid_amount');
      }
      const max = env.maxTipPence ?? DEFAULT_MAX_TIP_PENCE;
      if (raw < MIN_CHARGE_PENCE || raw > max) {
        throw new HttpError(400, `Tip must be between ${MIN_CHARGE_PENCE} and ${max} pence`, 'invalid_amount');
      }
      if (Number(booking.tip_amount) > 0) throw new HttpError(409, 'A tip has already been paid for this booking', 'already_paid');
      amountPence = raw;
      feePence = 0; // platform takes no fee on tips
      description = `Tip - booking ${booking.id}`;
      source = 'booking_tip';
    }

    if (feePence < 0) feePence = 0;
    if (feePence > amountPence) feePence = amountPence;

    // ---- 5. recipient / payment model ---------------------------------------------------------
    const accountId = await resolveRecipientAccountId(db, booking);
    const destination = accountId && (await accountIsPayoutReady(stripe, accountId)) ? accountId : null;
    const payoutMode: 'destination' | 'platform_hold' = destination ? 'destination' : 'platform_hold';
    if (!destination) {
      if (purpose === 'tip') {
        throw new HttpError(409, 'The valeter has not finished Stripe payout setup, so a tip cannot be taken yet', 'no_connected_account');
      }
      if (env.allowPlatformHold === false) {
        throw new HttpError(409, 'The valeter has not finished Stripe payout setup yet', 'no_connected_account');
      }
    }

    // ---- 6. create the PaymentIntent (idempotent) ---------------------------------------------
    const params: Record<string, any> = {
      amount: amountPence,
      currency,
      automatic_payment_methods: { enabled: true },
      description,
      transfer_group: `booking_${booking.id}`,
      metadata: {
        booking_id: String(booking.id),
        customer_id: callerId,
        valeter_id: String(booking.valeter_id || ''),
        source,
        request_message_id: requestMessageId,
        payout_mode: payoutMode,
        destination_account: destination ?? '',
        platform_fee_pence: String(feePence),
      },
    };
    if (destination) {
      params.transfer_data = { destination };
      if (feePence > 0) params.application_fee_amount = feePence;
    }

    const bucket = Math.floor((deps.now?.() ?? Date.now()) / 60_000);
    const dest = destination ?? 'hold';
    const baseKey =
      purpose === 'booking'
        ? `booking-pay-v2:${booking.id}:${amountPence}:${feePence}:${dest}`
        : purpose === 'request'
          ? `request-pay-v2:${booking.id}:${requestMessageId}:${amountPence}:${feePence}:${dest}`
          : `tip-v2:${booking.id}:${amountPence}:${bucket}`;

    let pi = await stripe.paymentIntents.create(params, { idempotencyKey: baseKey });
    if (pi.status === 'canceled') {
      pi = await stripe.paymentIntents.create(params, { idempotencyKey: `${baseKey}:retry:${deps.now?.() ?? Date.now()}` });
    }
    if (pi.status === 'succeeded') throw new HttpError(409, 'This payment has already been completed', 'already_paid');

    // ---- 7. persist bookkeeping (best effort; the webhook is the source of truth) --------------
    if (purpose === 'booking') {
      const { error } = await db.from('bookings').update({ payment_intent_id: pi.id }).eq('id', booking.id);
      if (error) console.warn('[booking-extra-charge] could not store payment_intent_id', error.message);
    } else if (purpose === 'request' && requestPayload) {
      const next = {
        ...requestPayload,
        kind: 'booking_payment_request',
        amount: amountPence / 100,
        currency,
        platformFee: feePence / 100,
        valeterShare: (amountPence - feePence) / 100,
        paymentIntentId: pi.id,
        paymentIntentClientSecret: null, // never store the client secret in chat; the app re-requests it (idempotent)
        status: 'pending',
        recipientStripeAccountId: destination ?? requestPayload.recipientStripeAccountId ?? null,
        payoutStatus: requestPayload.payoutStatus === 'released' ? 'released' : 'pending',
        paymentMode: payoutMode,
      };
      const { error } = await db.from('booking_messages').update({ content: JSON.stringify(next) }).eq('id', requestMessageId);
      if (error) console.warn('[booking-extra-charge] could not update payment request message', error.message);
    }

    return json(200, {
      ok: true,
      clientSecret: pi.client_secret,
      paymentIntentId: pi.id,
      amount: amountPence, // pence
      amountPence,
      platformFeePence: feePence,
      currency,
      purpose,
      payoutMode,
    });
  } catch (e: any) {
    if (e instanceof HttpError) return json(e.status, { error: e.message, code: e.code });
    console.error('[booking-extra-charge]', e?.type || '', e?.message || e);
    const isStripe = typeof e?.type === 'string' && e.type.startsWith('Stripe');
    return json(isStripe ? 502 : 500, {
      error: isStripe ? `Stripe error: ${e.message}` : 'Unexpected server error',
      code: isStripe ? 'stripe_error' : 'server_error',
    });
  }
}
