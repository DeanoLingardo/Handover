/**
 * Supabase Edge Function entrypoint: booking-extra-charge.
 * All logic lives in ./handler.ts so it can be unit tested offline.
 * Deploy:  supabase functions deploy booking-extra-charge        (JWT verification ON - callers are signed-in customers)
 * Secrets: STRIPE_SECRET_KEY (sk_test_... / sk_live_...). SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY are injected automatically.
 * Optional: STRIPE_ALLOW_PLATFORM_HOLD=false, MAX_TIP_PENCE, MAX_REQUEST_PENCE, MAX_BOOKING_PENCE
 */
import { createClient } from 'npm:@supabase/supabase-js@2';
import Stripe from 'npm:stripe@16.12.0';
import { handleRequest } from './handler.ts';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? '';
const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
const STRIPE_SECRET_KEY = Deno.env.get('STRIPE_SECRET_KEY') ?? '';

const db = createClient(SUPABASE_URL, SERVICE_ROLE);
const stripe = new Stripe(STRIPE_SECRET_KEY || 'sk_missing', { apiVersion: '2024-06-20' });

function intEnv(name: string): number | undefined {
  const n = Number(Deno.env.get(name));
  return Number.isInteger(n) && n > 0 ? n : undefined;
}

Deno.serve((req) => {
  if (!SUPABASE_URL || !SERVICE_ROLE || !STRIPE_SECRET_KEY) {
    return new Response(JSON.stringify({ error: 'Missing function environment variables.' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
    });
  }
  return handleRequest(req, {
    env: {
      stripeSecretKey: STRIPE_SECRET_KEY,
      allowPlatformHold: Deno.env.get('STRIPE_ALLOW_PLATFORM_HOLD') !== 'false',
      maxTipPence: intEnv('MAX_TIP_PENCE'),
      maxRequestPence: intEnv('MAX_REQUEST_PENCE'),
      maxBookingPence: intEnv('MAX_BOOKING_PENCE'),
    },
    getUser: async (token) => {
      const { data, error } = await db.auth.getUser(token);
      return error || !data?.user ? null : { id: data.user.id };
    },
    db,
    stripe,
  });
});
