/**
 * stripe-connect-webhook: request handler (dependency-injected for offline tests).
 *
 * Deploy with JWT verification OFF (Stripe does not send a Supabase JWT):
 *   supabase functions deploy stripe-connect-webhook --no-verify-jwt
 * (supabase/config.toml also sets verify_jwt = false for this function.)
 *
 * Two Stripe endpoints should point at this one URL, each with its own signing secret:
 *   - "Account" endpoint  (events on your platform account: payment_intent.*)  -> STRIPE_WEBHOOK_SECRET
 *   - "Connect" endpoint  (events on connected accounts: account.updated)      -> STRIPE_CONNECT_WEBHOOK_SECRET
 * The signature is checked against every configured secret; the first match wins.
 */

export type Deps = {
  env: { webhookSecrets: string[] };
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  stripe: any; // needs stripe.webhooks.constructEventAsync
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  db: any;
  now?: () => number;
};

// Booking states that are "waiting for payment" and may move to confirmed. Never regress later states.
export const AWAITING_PAYMENT_STATUSES = ['pending_payment', 'pending'];

function text(status: number, body: string) {
  return new Response(body, { status, headers: { 'Content-Type': 'text/plain' } });
}

function statusFromAccount(account: any): 'in_progress' | 'completed' | 'restricted' {
  if (account.details_submitted && account.charges_enabled && account.payouts_enabled) return 'completed';
  if ((account.requirements?.disabled_reason || '').length > 0) return 'restricted';
  return 'in_progress';
}

function safeParse(content: unknown): Record<string, any> | null {
  if (typeof content !== 'string' || !content) return null;
  try {
    const v = JSON.parse(content);
    return v && typeof v === 'object' ? v : null;
  } catch {
    return null;
  }
}

export async function handleRequest(req: Request, deps: Deps): Promise<Response> {
  const { db, stripe } = deps;
  const secrets = deps.env.webhookSecrets.filter(Boolean);
  if (secrets.length === 0) return text(500, 'No webhook signing secret configured (STRIPE_WEBHOOK_SECRET / STRIPE_CONNECT_WEBHOOK_SECRET).');
  if (req.method !== 'POST') return text(405, 'Method not allowed');

  const signature = req.headers.get('stripe-signature');
  if (!signature) return text(400, 'Missing stripe-signature header');

  const rawBody = await req.text();
  let event: any = null;
  for (const secret of secrets) {
    try {
      event = await stripe.webhooks.constructEventAsync(rawBody, signature, secret);
      break;
    } catch {
      /* try next secret */
    }
  }
  if (!event) return text(400, 'Invalid Stripe signature');

  const nowIso = () => new Date(deps.now?.() ?? Date.now()).toISOString();

  try {
    // ---------------------------------------------------------------- account.updated (Connect)
    if (event.type === 'account.updated') {
      const account = event.data.object;
      const nextStatus = statusFromAccount(account);
      const payload: Record<string, unknown> = {
        stripe_connect_status: nextStatus,
        stripe_account_id: account.id,
        stripe_details: {
          account_country: account.country,
          account_email: account.email,
          business_type: account.business_type,
          charges_enabled: account.charges_enabled,
          payouts_enabled: account.payouts_enabled,
          requirements: account.requirements,
          updated_from_stripe_webhook_at: nowIso(),
        },
      };
      if (nextStatus === 'completed') payload.stripe_onboarding_completed_at = nowIso();

      const userId = account.metadata?.user_id;
      const q = db.from('profiles').update(payload);
      const { error } = userId ? await q.eq('id', userId) : await q.eq('stripe_account_id', account.id);
      if (error) throw new Error(`profiles update failed: ${error.message}`);
      // live schema also keeps stripe_connect_status/stripe_account_id on valeter_profiles (keyed by user_id): keep in sync, best effort
      const vpPayload: Record<string, unknown> = { stripe_connect_status: nextStatus, stripe_account_id: account.id };
      if (nextStatus === 'completed') vpPayload.stripe_onboarding_completed_at = nowIso();
      const vq = db.from('valeter_profiles').update(vpPayload);
      const vp = userId ? await vq.eq('user_id', userId) : await vq.eq('stripe_account_id', account.id);
      if (vp.error) console.warn('[stripe-connect-webhook] valeter_profiles sync failed:', vp.error.message);
    }

    // ------------------------------------------------ payment_intent.succeeded / payment_failed
    if (event.type === 'payment_intent.succeeded' || event.type === 'payment_intent.payment_failed') {
      const intent = event.data.object;
      const succeeded = event.type === 'payment_intent.succeeded';
      const md = intent.metadata ?? {};
      const bookingId: string = md.booking_id || md.bookingId || '';
      const requestMessageId: string = md.request_message_id || '';

      if (requestMessageId) {
        // chat payment request: keep the message in sync
        const { data: message } = await db.from('booking_messages').select('content').eq('id', requestMessageId).maybeSingle();
        const current = safeParse(message?.content);
        if (current) {
          const viaDestination = !!intent.transfer_data?.destination || md.payout_mode === 'destination';
          const next: Record<string, any> = {
            ...current,
            status: succeeded ? 'paid' : 'failed',
            paymentIntentId: intent.id,
            paymentIntentClientSecret: null,
            paidAt: succeeded ? nowIso() : current.paidAt ?? null,
            failedAt: !succeeded ? nowIso() : current.failedAt ?? null,
          };
          if (succeeded && viaDestination) {
            // destination charge: Stripe has already paid the connected account
            next.payoutStatus = 'released';
            next.payoutReleasedAt = current.payoutReleasedAt ?? nowIso();
          }
          const { error } = await db.from('booking_messages').update({ content: JSON.stringify(next) }).eq('id', requestMessageId);
          if (error) throw new Error(`booking_messages update failed: ${error.message}`);
        }
      } else if (bookingId && succeeded) {
        if (md.source === 'booking_tip') {
          // tip: record the amount server-side too (best effort; the client also writes it)
          const { error } = await db
            .from('bookings')
            .update({ tip_amount: intent.amount / 100 })
            .eq('id', bookingId);
          if (error) console.warn('[stripe-connect-webhook] tip_amount update failed:', error.message);
        } else {
          // main booking payment -> source of truth for "paid"
          const stamp = await db
            .from('bookings')
            .update({ payment_completed_at: nowIso() })
            .eq('id', bookingId)
            .is('payment_completed_at', null);
          if (stamp.error) throw new Error(`bookings payment_completed_at update failed: ${stamp.error.message}`);
          // live column is bookings.payment_intent_id; best effort, must never block confirmation
          const piStore = await db.from('bookings').update({ payment_intent_id: intent.id }).eq('id', bookingId);
          if (piStore.error) console.warn('[stripe-connect-webhook] payment_intent_id not stored:', piStore.error.message);

          const conf = await db
            .from('bookings')
            .update({ status: 'confirmed' })
            .eq('id', bookingId)
            .in('status', AWAITING_PAYMENT_STATUSES);
          if (conf.error) throw new Error(`bookings status update failed: ${conf.error.message}`);
        }
      }
    }

    return text(200, 'ok');
  } catch (e: any) {
    console.error('[stripe-connect-webhook] handler error', e?.message || e);
    // 500 so Stripe retries transient DB failures
    return text(500, e?.message || 'Webhook handler error');
  }
}
