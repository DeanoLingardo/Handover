// supabase/functions/stripe-connect-webhook/index.ts  (logic in ./handler.ts)
import { createClient } from 'npm:@supabase/supabase-js@2';
import Stripe from 'npm:stripe@16.12.0';
import { handleRequest } from './handler.ts';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? '';
const SERVICE_ROLE = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
const STRIPE_SECRET_KEY = Deno.env.get('STRIPE_SECRET_KEY') ?? '';
// Account endpoint secret + Connect endpoint secret (either may be omitted if you only use one endpoint)
const WEBHOOK_SECRETS = [Deno.env.get('STRIPE_WEBHOOK_SECRET') ?? '', Deno.env.get('STRIPE_CONNECT_WEBHOOK_SECRET') ?? ''];

const db = createClient(SUPABASE_URL, SERVICE_ROLE);
const stripe = new Stripe(STRIPE_SECRET_KEY || 'sk_missing', { apiVersion: '2024-06-20' });

Deno.serve((req) => {
  if (!SUPABASE_URL || !SERVICE_ROLE || !STRIPE_SECRET_KEY) {
    return new Response('Missing function environment variables.', { status: 500 });
  }
  return handleRequest(req, { env: { webhookSecrets: WEBHOOK_SECRETS }, stripe, db });
});
