# Enabling RLS on bookings / booking_messages (ADVICE ONLY - not applied)

Live state: RLS is OFF on all 21 public tables, so anyone with the public anon key (it ships in the apps) can read/modify
every booking, chat message and profile (incl. stripe_account_id) straight through PostgREST. Edge functions use the service
role and are unaffected by RLS, so the Stripe functions keep working.

Do it on a staging copy / in a quiet window, one table at a time, and re-test both apps after each:

```sql
alter table public.bookings enable row level security;
create policy bookings_customer_rw on public.bookings for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy bookings_valeter_read on public.bookings for select to authenticated
  using (valeter_id = auth.uid());
create policy bookings_valeter_update on public.bookings for update to authenticated
  using (valeter_id = auth.uid()) with check (valeter_id = auth.uid());
-- also needed: a policy letting valeters SEE open requests/pending_valeter_acceptance jobs (app-specific), and business/org
-- members seeing bookings for their locations (location_id -> car_wash_locations.organization_id -> profiles.organization_id).

alter table public.booking_messages enable row level security;
create policy msgs_participants_read on public.booking_messages for select to authenticated using (
  exists (select 1 from public.bookings b where b.id = booking_id and (b.user_id = auth.uid() or b.valeter_id = auth.uid())));
create policy msgs_participants_insert on public.booking_messages for insert to authenticated with check (
  sender_id = auth.uid() and exists (select 1 from public.bookings b where b.id = booking_id and (b.user_id = auth.uid() or b.valeter_id = auth.uid())));
-- no UPDATE policy: only the edge functions (service role) change payment_request content.
```
Notes: (1) Once RLS is on, customers can no longer write `payment_completed_at`/`status='confirmed'` themselves - the webhook does it
(the customer app already polls for that and its fallback write will simply be refused). Also consider column-level protection
so customers can't edit `price`/`platform_fee_*` on their own booking (a trigger or restricting UPDATE to cancel/rating columns).
(2) Valeter chat payment requests are inserted by the valeter app as a normal message - covered by the insert policy.
(3) Check the Supabase security advisor afterwards (`get_advisors`). Until RLS is on, anyone could also forge a `payment_request`
message from a valeter; the function blocks customer-authored ones, but not a forged `sender_role`/`sender_id` - another reason to enable it.
