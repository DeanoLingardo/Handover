/**
 * Auth e-mail link helpers (shared design between Wish a Wash and Wish a Washer).
 *
 * - Builds the per-app `emailRedirectTo` / reset `redirectTo` (https landing page on Dean's domain).
 * - Reads auth payloads from ANY of the formats Supabase can send back:
 *     ?code=...                              (PKCE)
 *     ?token_hash=...&type=...               (template style, use with verifyOtp)
 *     #access_token=...&refresh_token=...    (implicit flow / {{ .ConfirmationURL }})
 *   either directly on the app deep link or forwarded by the landing page (which converts the
 *   fragment into query params because custom-scheme links lose the fragment in Expo Router).
 * - Turns them into a Supabase session.
 */
import * as Linking from 'expo-linking';
import type { EmailOtpType, Session, User } from '@supabase/supabase-js';
import { supabase } from './supabase';

/** Which app this build is. Sent to Supabase as user_metadata.app and used in the redirect path. */
export const AUTH_APP = 'valeter' as const;
/** Must match `scheme` in app.config.ts. */
export const AUTH_SCHEME = 'wawv' as const;

export const DUPLICATE_EMAIL_MESSAGE =
  'This email is already registered; please sign in or use another email';

/**
 * Base URL of the auth landing page (WITHOUT the per-app suffix), e.g. https://YOUR-DOMAIN/open
 * Set EXPO_PUBLIC_AUTH_REDIRECT_BASE in EAS / .env. The app appends `/valeter`.
 * (A value that already ends in /customer or /valeter is accepted too.)
 *
 * TODO(Dean): DECISION NEEDED - choose the domain that hosts auth-emails/landing/index.html.
 * Until it is set the app falls back to its own deep link, which works but is not clickable in
 * every mail client and does nothing on desktop.
 *
 * NOTE: must be referenced as `process.env.EXPO_PUBLIC_...` so Expo inlines it at build time.
 */
const RAW_BASE = (process.env.EXPO_PUBLIC_AUTH_REDIRECT_BASE ?? '').trim();

let warned = false;

function landingUrl(fallbackPath: string): string {
  const base = RAW_BASE.replace(/\/+$/, '').replace(/\/(customer|valeter)$/i, '');
  if (base) return `${base}/${AUTH_APP}`;
  if (!warned) {
    warned = true;
    console.warn(
      '[auth] EXPO_PUBLIC_AUTH_REDIRECT_BASE is not set - e-mail links will use the app deep link instead of the https landing page.'
    );
  }
  return Linking.createURL(fallbackPath);
}

/** `emailRedirectTo` for signUp / resend / magic link. */
export function buildAuthRedirect(): string {
  return landingUrl('/auth/callback');
}

/** `redirectTo` for resetPasswordForEmail (the landing page sends type=recovery links to the reset screen). */
export function buildResetRedirect(): string {
  return landingUrl('/auth/reset-password');
}

/** Supabase "fake success" for an already-registered e-mail: user returned with an empty identities list. */
export function isDuplicateSignUp(data: { user?: User | null } | null | undefined): boolean {
  const user = data?.user;
  return !!user && Array.isArray(user.identities) && user.identities.length === 0;
}

export class DuplicateEmailError extends Error {
  code = 'EMAIL_ALREADY_REGISTERED' as const;
  constructor() {
    super(DUPLICATE_EMAIL_MESSAGE);
    this.name = 'DuplicateEmailError';
  }
}

export type AuthParams = Record<string, string>;

function decode(v: string): string {
  try {
    return decodeURIComponent(v.replace(/\+/g, ' '));
  } catch {
    return v;
  }
}

function parsePairs(s: string, into: AuthParams) {
  if (!s) return;
  for (const part of s.split('&')) {
    if (!part) continue;
    const i = part.indexOf('=');
    const k = decode(i >= 0 ? part.slice(0, i) : part);
    const v = i >= 0 ? decode(part.slice(i + 1)) : '';
    if (k && !(k in into)) into[k] = v;
  }
}

/** Parses both ?query and #fragment of a URL string. Query wins on duplicate keys. */
export function parseAuthUrl(url?: string | null): AuthParams {
  const out: AuthParams = {};
  if (!url) return out;
  const hashIdx = url.indexOf('#');
  const frag = hashIdx >= 0 ? url.slice(hashIdx + 1) : '';
  const beforeHash = hashIdx >= 0 ? url.slice(0, hashIdx) : url;
  const qIdx = beforeHash.indexOf('?');
  if (qIdx >= 0) parsePairs(beforeHash.slice(qIdx + 1), out);
  parsePairs(frag, out);
  return out;
}

/** Merges Expo Router search params with whatever the raw URL carried (incl. the fragment). */
export function collectAuthParams(
  routeParams?: Record<string, string | string[] | undefined> | null,
  url?: string | null
): AuthParams {
  const out: AuthParams = {};
  for (const [k, v] of Object.entries(routeParams ?? {})) {
    const s = Array.isArray(v) ? v[0] : v;
    if (typeof s === 'string') out[k] = s;
  }
  const fromUrl = parseAuthUrl(url);
  for (const [k, v] of Object.entries(fromUrl)) if (!(k in out)) out[k] = v;
  return out;
}

export function hasAuthPayload(p: AuthParams): boolean {
  return !!(p.code || p.token_hash || (p.access_token && p.refresh_token) || p.error || p.error_description);
}

export function normalizeAuthType(p: AuthParams): string {
  const t = (p.type ?? '').toLowerCase();
  return t === 'password_recovery' ? 'recovery' : t;
}

export function isRecoveryLink(p: AuthParams): boolean {
  return normalizeAuthType(p) === 'recovery';
}

const OTP_TYPES: EmailOtpType[] = ['signup', 'invite', 'magiclink', 'recovery', 'email_change', 'email'];

export type EstablishResult = {
  handled: boolean;
  type: string;
  session: Session | null;
  user: User | null;
};

const inflight = new Map<string, Promise<EstablishResult>>();

function friendlyAuthError(p: AuthParams): string {
  const desc = p.error_description || p.error || '';
  if ((p.error_code ?? '').includes('otp_expired') || /expired|invalid/i.test(desc)) {
    return 'This link has expired or was already used. Please request a new one.';
  }
  return desc || 'Unable to complete this link.';
}

/**
 * Turns an auth link payload into a Supabase session.
 * Supports: token_hash+type (verifyOtp), access_token+refresh_token (setSession), code (PKCE exchange).
 * Calls with the same payload share one request so a re-render cannot consume a one-time token twice.
 */
export function establishSessionFromAuthParams(p: AuthParams): Promise<EstablishResult> {
  const key = JSON.stringify([p.code, p.token_hash, p.type, p.access_token, p.refresh_token, p.error, p.error_description]);
  const existing = inflight.get(key);
  if (existing) return existing;

  const run = (async (): Promise<EstablishResult> => {
    const type = normalizeAuthType(p);
    if (p.error || p.error_description) throw new Error(friendlyAuthError(p));

    if (p.token_hash) {
      const otpType = (type || 'email') as EmailOtpType;
      if (!OTP_TYPES.includes(otpType)) throw new Error('Unsupported link type.');
      const { data, error } = await supabase.auth.verifyOtp({ token_hash: p.token_hash, type: otpType });
      if (error) throw error;
      return { handled: true, type, session: data.session ?? null, user: data.user ?? data.session?.user ?? null };
    }
    if (p.access_token && p.refresh_token) {
      const { data, error } = await supabase.auth.setSession({
        access_token: p.access_token,
        refresh_token: p.refresh_token,
      });
      if (error) throw error;
      return { handled: true, type, session: data.session ?? null, user: data.user ?? data.session?.user ?? null };
    }
    if (p.code) {
      const { data, error } = await supabase.auth.exchangeCodeForSession(p.code);
      if (error) throw error;
      return { handled: true, type, session: data.session ?? null, user: data.user ?? data.session?.user ?? null };
    }
    return { handled: false, type, session: null, user: null };
  })();

  inflight.set(key, run);
  // Keep successful results briefly (re-render protection), drop failures straight away.
  run.then(
    () => setTimeout(() => inflight.delete(key), 30000),
    () => inflight.delete(key)
  );
  return run;
}
