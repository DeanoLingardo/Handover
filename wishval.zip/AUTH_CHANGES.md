# Auth e-mail fix – valeter app (Wish a Washer, scheme `wawv`)
Built on WishaWasher-fixed-live (earlier Stripe fixes untouched). Patch: `auth-fix.patch`.

| File | Why |
|---|---|
| `src/lib/authLinks.ts` (new) | Per-app redirect builder (`EXPO_PUBLIC_AUTH_REDIRECT_BASE` + `/valeter`, deep-link fallback if unset), parser for ?code / ?token_hash&type / #access_token fragments, session establishment (verifyOtp / setSession / exchangeCodeForSession, de-duplicated), duplicate-sign-up detector |
| `src/providers/enhanced-auth-context.tsx` | signUp sends `data.app='valeter'` (userType valeter/organization kept) and `emailRedirectTo` = https landing; reset redirect likewise; duplicate e-mail (empty `identities`) throws the "already registered" message; OAuth completion uses the shared link handler (fragment tokens too) |
| `src/components/valeter/onboarding/ProSetupWizard.tsx` | Show the "already registered" message from the new duplicate error |
| `app/auth/callback.tsx` | Handles code, token_hash+type and fragment tokens; recovery links go to `/auth/reset-password`; error + "Back to sign in" |
| `app/auth/reset-password.tsx` | Existing screen only handled `?code=`; now handles token_hash, code and fragment/query tokens, with a short grace wait for the raw URL |
| `env.example` | Documents `EXPO_PUBLIC_AUTH_REDIRECT_BASE` |
| `src/lib/__tests__/authLinks.test.ts` (new) | Unit tests for the link helpers (8 tests) |
| `tsconfig.json` | Exclude `src/**/__tests__` from the app type-check |
