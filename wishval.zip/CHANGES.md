# Stripe fixes – what changed and why

Repos: `customer/` (WishaWash 57, scheme `waw`) and `valeter/` (WishaWasher++, scheme `wawv`). Each has `stripe-fixes.patch`
(git patch against the original; verified: original + patch == fixed). Nothing has been deployed; no keys are in the code.

## Root causes found
1. Two *different* `booking-extra-charge` functions existed (customer trusted client `amount`/`customerId`; valeter used chat-request logic) – whichever was deployed broke the other app.
2. Main-booking payment sent a client-side amount; no ownership check; no server-side confirmation – the app only trusted the phone.
3. Valeter payout could pay twice (destination charge AND a later transfer) or not at all for main bookings.
4. Webhook did not confirm bookings; single signing secret only (Account vs Connect endpoints need two); no `config.toml` so JWT verification would block Stripe.
5. `stripe-connect` created accounts without country/capabilities (payments not enabled).
6. Client issues: valeter `urlScheme` wrong, customer publishable key hard-coded, dead `StripePaymentService.ts`, misleading payout toast.

## Fixes
| Area | Change |
|---|---|
| `booking-extra-charge` (identical in both repos) | One function, 3 purposes: `booking` (amount = `bookings.price` from DB), `request` (chat payment request), `tip` (validated 50p–£100, completed booking, once). JWT auth; caller must own the booking (403). Destination charge + application fee when valeter is payout-ready; otherwise platform hold. Idempotency keys; already-paid -> 409. |
| `booking-release-payout` | Caller must be the valeter/org member, booking completed. Destination charge: no extra transfer (returns existing). Hold: exactly one idempotent transfer. Works for main bookings. |
| `stripe-connect-webhook` | Verifies against two secrets (`STRIPE_WEBHOOK_SECRET`, `STRIPE_CONNECT_WEBHOOK_SECRET`). `payment_intent.succeeded` -> booking `confirmed` (only from pending_payment), `payment_completed_at`, request/tip updates; idempotent; 500 on DB error so Stripe retries. `account.updated` syncs profile. |
| `stripe-connect` | Express accounts, country GB, `card_payments` + `transfers` capabilities (also requested for existing accounts). |
| `config.toml`, `DEPLOY.md`, migration (no migration needed on live - see DEPLOY.md) | Webhook `verify_jwt=false`; deploy steps; adds columns + widens chat check constraints (idempotent; checked on Postgres via PGlite). |
| Customer app | No amount sent for main booking; polls server booking state after pay (guarded optimistic fallback); publishable key from `EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY`; tip/request use new function; `StripePaymentService.ts` deleted. |
| Valeter app | `urlScheme: wawv`, env publishable key; payment-request service surfaces error codes; payout toasts reflect real outcome. |

## Verification actually run
* `stripe-test`: `npm test` -> 46/46 pass (handlers, webhook, payout, static checks, plus the e2e script run against a local mock). Mutation checks confirmed tests fail when guards are removed.
* `deno check` of all functions (Stripe 16.12 types) – passes except one pre-existing generic type error in `stripe-connect/index.ts` (no runtime effect).
* `tsc --noEmit` on both apps: no new errors vs originals (customer 350 pre-existing, valeter 3 pre-existing missing-asset errors).
* Migration SQL run twice on Postgres (PGlite).

## NOT verified (needs your Stripe/Supabase)
Real Stripe API behaviour, real webhook delivery, the PaymentSheet UI on a device, live-DB constraint names. Run `stripe-test/e2e-test-mode.mjs` then the phone pass in `stripe-test/README.md`.
