jest.mock('expo-linking', () => ({ createURL: (p: string) => `waw://${p.replace(/^\//, '')}` }));
const mockVerifyOtp = jest.fn(async () => ({ data: { session: { user: { id: 'u' } }, user: { id: 'u' } }, error: null }));
const mockSetSession = jest.fn(async () => ({ data: { session: { user: { id: 'u' } }, user: { id: 'u' } }, error: null }));
const mockExchange = jest.fn(async () => ({ data: { session: { user: { id: 'u' } }, user: { id: 'u' } }, error: null }));
jest.mock('../supabase', () => ({
  supabase: {
    auth: {
      verifyOtp: (...a: any[]) => (mockVerifyOtp as any)(...a),
      setSession: (...a: any[]) => (mockSetSession as any)(...a),
      exchangeCodeForSession: (...a: any[]) => (mockExchange as any)(...a),
    },
  },
}));

import {
  parseAuthUrl,
  collectAuthParams,
  hasAuthPayload,
  isRecoveryLink,
  isDuplicateSignUp,
  establishSessionFromAuthParams,
  buildAuthRedirect,
  AUTH_APP,
} from '../authLinks';

describe('authLinks', () => {
  beforeEach(() => jest.clearAllMocks());

  it('parses query and fragment', () => {
    expect(parseAuthUrl('x://auth/callback?code=abc&type=signup')).toEqual({ code: 'abc', type: 'signup' });
    expect(parseAuthUrl('https://d/open/x#access_token=a%2Bb&refresh_token=r&type=recovery')).toEqual({
      access_token: 'a+b',
      refresh_token: 'r',
      type: 'recovery',
    });
  });

  it('merges route params with the raw url fragment', () => {
    const p = collectAuthParams({ type: 'recovery' }, 'x://reset#access_token=a&refresh_token=r');
    expect(p).toEqual({ type: 'recovery', access_token: 'a', refresh_token: 'r' });
    expect(hasAuthPayload(p)).toBe(true);
    expect(isRecoveryLink(p)).toBe(true);
    expect(hasAuthPayload({})).toBe(false);
  });

  it('detects the duplicate-email fake success', () => {
    expect(isDuplicateSignUp({ user: { identities: [] } as any })).toBe(true);
    expect(isDuplicateSignUp({ user: { identities: [{ id: 1 }] } as any })).toBe(false);
    expect(isDuplicateSignUp({ user: null })).toBe(false);
  });

  it('uses verifyOtp for token_hash, setSession for tokens, exchange for code', async () => {
    await establishSessionFromAuthParams({ token_hash: 'th', type: 'recovery' });
    expect(mockVerifyOtp).toHaveBeenCalledWith({ token_hash: 'th', type: 'recovery' });
    await establishSessionFromAuthParams({ access_token: 'a', refresh_token: 'r', type: 'signup' });
    expect(mockSetSession).toHaveBeenCalledWith({ access_token: 'a', refresh_token: 'r' });
    await establishSessionFromAuthParams({ code: 'c1' });
    expect(mockExchange).toHaveBeenCalledWith('c1');
  });

  it('does not consume the same token twice', async () => {
    await establishSessionFromAuthParams({ token_hash: 'same', type: 'email' });
    await establishSessionFromAuthParams({ token_hash: 'same', type: 'email' });
    expect(mockVerifyOtp).toHaveBeenCalledTimes(1);
  });

  it('surfaces link errors in friendly words', async () => {
    await expect(
      establishSessionFromAuthParams({ error: 'access_denied', error_code: 'otp_expired', error_description: 'Email link is invalid or has expired' })
    ).rejects.toThrow(/expired or was already used/);
  });

  it('redirect: https landing when base set is app-specific; deep link otherwise', () => {
    expect(AUTH_APP).toBe('customer');
    expect(buildAuthRedirect()).toBe('waw://auth/callback');
  });

  it('redirect: https landing + app suffix when EXPO_PUBLIC_AUTH_REDIRECT_BASE is set (suffix tolerated)', () => {
    const prev = process.env.EXPO_PUBLIC_AUTH_REDIRECT_BASE;
    for (const base of ['https://example.com/open', 'https://example.com/open/', 'https://example.com/open/valeter']) {
      process.env.EXPO_PUBLIC_AUTH_REDIRECT_BASE = base;
      jest.isolateModules(() => {
        const mod = require('../authLinks');
        expect(mod.buildAuthRedirect()).toBe(`https://example.com/open/${mod.AUTH_APP}`);
        expect(mod.buildResetRedirect()).toBe(`https://example.com/open/${mod.AUTH_APP}`);
      });
    }
    process.env.EXPO_PUBLIC_AUTH_REDIRECT_BASE = prev;
  });
});
