import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StatusBar,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import * as Linking from 'expo-linking';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import {
  collectAuthParams,
  establishSessionFromAuthParams,
  hasAuthPayload,
} from '../../src/lib/authLinks';
import { WWPrimaryButton } from '../../src/components/ui';

const SKY = '#87CEEB';

/**
 * Customer "choose a new password" screen.
 * Reached via waw://reset-password (or /auth/reset-password) from the password-reset e-mail, usually through
 * the https landing page, which forwards the link payload:
 *   ?token_hash=&type=recovery   |   ?code=   |   access_token/refresh_token (query or #fragment)
 */
export default function ResetPasswordScreen() {
  const insets = useSafeAreaInsets();
  const { updatePassword, logout } = useAuth();
  const routeParams = useLocalSearchParams();
  const url = Linking.useURL();

  const authParams = useMemo(
    () => collectAuthParams(routeParams as Record<string, string | string[] | undefined>, url),
    [routeParams, url]
  );
  const authSignature = JSON.stringify(authParams);

  const [ready, setReady] = useState(false);
  const [bootError, setBootError] = useState<string | null>(null);
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const confirmRef = useRef<TextInput>(null);

  useEffect(() => {
    let cancelled = false;

    const boot = async () => {
      try {
        if (hasAuthPayload(authParams)) {
          await establishSessionFromAuthParams(authParams);
        } else {
          // The raw URL (with its #fragment) can arrive a moment after the first render.
          await new Promise((r) => setTimeout(r, 700));
          if (cancelled) return;
        }
        const { data } = await supabase.auth.getSession();
        if (!data.session) {
          throw new Error('Reset link expired or invalid. Request a new one from sign in.');
        }
        if (!cancelled) {
          setBootError(null);
          setReady(true);
        }
      } catch (e: any) {
        if (!cancelled) setBootError(e?.message || 'Unable to open password reset.');
      }
    };

    void boot();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authSignature]);

  const handleSave = async () => {
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirm) {
      setError('Passwords don’t match.');
      return;
    }
    setError(null);
    setSaving(true);
    try {
      await updatePassword('', password);
      try {
        await logout();
      } catch {
        await supabase.auth.signOut();
      }
      setDone(true);
    } catch (e: any) {
      setError(e?.message || 'Couldn’t update password. Try the reset link again.');
    } finally {
      setSaving(false);
    }
  };

  const title = bootError ? 'Link expired' : done ? 'Password updated' : 'Choose a new password';
  const subtitle = bootError
    ? bootError
    : done
      ? 'You’re all set. Sign in with your new password.'
      : 'Enter a new password for your Wish a Wash account, then sign in again.';
  const icon: React.ComponentProps<typeof Ionicons>['name'] = bootError
    ? 'time-outline'
    : done
      ? 'checkmark-circle-outline'
      : 'lock-closed-outline';

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          contentContainerStyle={[
            styles.scroll,
            { paddingTop: insets.top + 24, paddingBottom: Math.max(insets.bottom, 20) + 16 },
          ]}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.card}>
            <View style={styles.badge}>
              <Ionicons name={icon} size={28} color={done ? '#4ADE80' : '#F8FAFC'} />
            </View>
            <Text style={styles.title}>{title}</Text>
            <Text style={styles.subtitle}>{subtitle}</Text>

            {!ready && !bootError ? (
              <View style={styles.loadingWrap}>
                <ActivityIndicator color={SKY} />
                <Text style={styles.loadingText}>Opening secure reset…</Text>
              </View>
            ) : null}

            {bootError || done ? (
              <WWPrimaryButton
                title={done ? 'Sign in' : 'Back to sign in'}
                onPress={() => router.replace('/auth/login' as any)}
              />
            ) : null}

            {ready && !done ? (
              <View>
                <View style={styles.inputWrapper}>
                  <Ionicons name="lock-closed-outline" size={20} color={SKY} style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="New password"
                    placeholderTextColor="rgba(148,163,184,0.75)"
                    value={password}
                    onChangeText={(v) => {
                      setPassword(v);
                      if (error) setError(null);
                    }}
                    secureTextEntry
                    autoCapitalize="none"
                    autoCorrect={false}
                    autoComplete="new-password"
                    textContentType="newPassword"
                    returnKeyType="next"
                    onSubmitEditing={() => confirmRef.current?.focus()}
                    accessibilityLabel="New password"
                  />
                </View>
                <View style={styles.inputWrapper}>
                  <Ionicons name="shield-checkmark-outline" size={20} color={SKY} style={styles.inputIcon} />
                  <TextInput
                    ref={confirmRef}
                    style={styles.input}
                    placeholder="Confirm new password"
                    placeholderTextColor="rgba(148,163,184,0.75)"
                    value={confirm}
                    onChangeText={(v) => {
                      setConfirm(v);
                      if (error) setError(null);
                    }}
                    secureTextEntry
                    autoCapitalize="none"
                    autoCorrect={false}
                    autoComplete="new-password"
                    textContentType="newPassword"
                    returnKeyType="done"
                    onSubmitEditing={() => void handleSave()}
                    accessibilityLabel="Confirm new password"
                  />
                </View>
                {error ? (
                  <View style={styles.errorRow}>
                    <Ionicons name="warning-outline" size={18} color="#F87171" />
                    <Text style={styles.errorText}>{error}</Text>
                  </View>
                ) : null}
                <WWPrimaryButton
                  title={saving ? 'Saving…' : 'Save new password'}
                  onPress={() => void handleSave()}
                  disabled={saving || !password || !confirm}
                  loading={saving}
                  style={styles.cta}
                />
              </View>
            ) : null}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0A1929' },
  flex: { flex: 1 },
  scroll: { flexGrow: 1, paddingHorizontal: 18, justifyContent: 'center' },
  card: {
    borderRadius: 24,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
    backgroundColor: 'rgba(8,24,40,0.75)',
    padding: 22,
    gap: 6,
  },
  badge: {
    width: 56,
    height: 56,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(158,201,224,0.45)',
    backgroundColor: 'rgba(158,201,224,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  title: { color: '#F8FAFC', fontSize: 24, fontWeight: '800', letterSpacing: -0.4 },
  subtitle: {
    color: 'rgba(226,240,250,0.75)',
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '600',
    marginBottom: 16,
  },
  loadingWrap: { alignItems: 'center', gap: 12, paddingVertical: 24 },
  loadingText: { color: 'rgba(226,240,250,0.7)', fontSize: 14, fontWeight: '600' },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
    backgroundColor: 'rgba(15,23,42,0.6)',
    paddingHorizontal: 12,
    marginBottom: 12,
  },
  inputIcon: { marginRight: 8 },
  input: { flex: 1, color: '#F8FAFC', fontSize: 16, paddingVertical: 14 },
  errorRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  errorText: { color: '#F87171', fontSize: 14, flex: 1 },
  cta: { marginTop: 4 },
});
