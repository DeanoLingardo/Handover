import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, ActivityIndicator, StyleSheet, TouchableOpacity } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import * as Linking from 'expo-linking';
import {
  collectAuthParams,
  establishSessionFromAuthParams,
  hasAuthPayload,
  isRecoveryLink,
} from '../../src/lib/authLinks';

/**
 * Handles every link back into the app: sign-up confirmation, magic link, e-mail change, OAuth.
 * Supported payloads (query on the deep link, or forwarded from the https landing page):
 *   ?code=            ?token_hash=&type=            #access_token=&refresh_token=&type=
 * Password-recovery links are passed straight to the reset-password screen (which consumes them).
 */
export default function AuthCallbackScreen() {
  const routeParams = useLocalSearchParams();
  const url = Linking.useURL();
  const [message, setMessage] = useState('Completing sign in...');
  const [failed, setFailed] = useState(false);

  const params = useMemo(
    () => collectAuthParams(routeParams as Record<string, string | string[] | undefined>, url),
    [routeParams, url]
  );
  const signature = JSON.stringify(params);

  useEffect(() => {
    let cancelled = false;

    // Opened without any payload (e.g. OAuth screen already handled by the auth provider):
    // give a raw URL (fragment) a moment to arrive, then carry on to the app.
    if (!hasAuthPayload(params)) {
      const t = setTimeout(() => {
        if (!cancelled) router.replace('/');
      }, 800);
      return () => {
        cancelled = true;
        clearTimeout(t);
      };
    }

    const finish = async () => {
      try {
        if (isRecoveryLink(params)) {
          // Do not consume the one-time token here; the reset screen does it.
          router.replace({ pathname: '/auth/reset-password', params } as any);
          return;
        }
        await establishSessionFromAuthParams(params);
        if (!cancelled) router.replace('/');
      } catch (error: any) {
        if (!cancelled) {
          setFailed(true);
          setMessage(error?.message || 'Unable to complete sign in.');
        }
      }
    };

    void finish();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [signature]);

  return (
    <View style={styles.container}>
      {failed ? null : <ActivityIndicator color="#87CEEB" />}
      <Text style={styles.text}>{message}</Text>
      {failed ? (
        <TouchableOpacity onPress={() => router.replace('/auth/login' as any)} accessibilityRole="button">
          <Text style={styles.link}>Back to sign in</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    backgroundColor: '#0A1929',
    gap: 16,
  },
  text: {
    color: '#F9FAFB',
    textAlign: 'center',
    fontSize: 16,
    lineHeight: 22,
  },
  link: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
});
