import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Linking,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { LinearGradient } from 'expo-linear-gradient';
import AppHeader from '../../../src/components/shared/AppHeader';
import { useOwnerScrollContentPadding } from '../../../src/hooks/useOwnerScrollContentPadding';
import { CONTENT_PADDING_H, SECTION_GAP } from '../../../src/constants/pageStyles';
import { colors } from '../../../src/constants/colors';
import GradientIconBox from '../../../src/components/shared/GradientIconBox';
import { MOBILE_SERVICE_ONLY_LAUNCH } from '../../../src/constants/launchCustomerScope';
import { CCP, ccpPluralLower, ccpSingularLower } from '../../../src/constants/carCareProLabels';
import { SUPPORT_EMAIL } from '../../../src/constants/contactEmails';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const ACCENT = colors.ECO_GREEN;
const POLICY_URL = 'https://www.instagram.com/wishawash.app/';

export default function HelpSupport() {
  const scrollPad = useOwnerScrollContentPadding(true);
  const [expandedFAQ, setExpandedFAQ] = useState<string | null>(null);

  // Updated FAQ
  const faqs = [
    {
      id: '1',
      question: 'How do I book a car wash service?',
      answer: MOBILE_SERVICE_ONLY_LAUNCH
        ? `**Booking Process:**\n\n1. Tap "Book A Wish" on your dashboard\n2. Confirm your location\n3. Select your vehicle (or add one if needed)\n4. Make a wish\n5. Pick a ${ccpSingularLower()} and review\n6. Confirm and pay\n\nA ${ccpSingularLower()} will be assigned within 5-10 minutes.`
        : `**Booking Process:**\n\n1. Tap "Book a Wash" on your dashboard\n2. Choose between "${CCP.singular}" (${ccpSingularLower()} comes to you) or "Go to Car Wash" (physical car wash)\n3. Select your vehicle (or add one if needed)\n4. Choose service type\n5. Set your location\n6. Review and confirm\n\nA ${ccpSingularLower()} will be assigned within 5-10 minutes for mobile bookings.`,
      category: 'booking'
    },
    {
      id: '2',
      question: 'What is the cancellation policy?',
      answer: '**Cancellation & Refund Policy:**\n\n**Mobile Bookings:**\n• Within 5 minutes: 100% refund\n• Within 15 minutes: 90% refund\n• Within 30 minutes: 75% refund\n• Within 1 hour: 50% refund\n• After 1 hour: No refund\n\n**Scheduled Bookings:**\n• Cancel 24+ hours before: Full refund\n• Cancel 12-24 hours before: 75% refund\n• Cancel less than 12 hours: No refund\n\n**Processing:** Refunds are processed within 24-48 hours to your original payment method.',
      category: 'refunds'
    },
    {
      id: '3',
      question: `How do I track my ${ccpSingularLower()}?`,
      answer: `**Real-Time Tracking:**\n\nOnce a ${ccpSingularLower()} accepts your booking:\n• View their live location on the map\n• See estimated arrival time (ETA)\n• Track their route in real-time\n• Updates every 30 seconds\n\n**If tracking isn't working:**\n1. Refresh the app\n2. Check your internet connection\n3. Ensure location permissions are enabled`,
      category: 'tracking'
    },
    {
      id: '4',
      question: 'What payment methods are accepted?',
      answer: '**Payment Methods:**\n\n**Accepted:**\n• Visa, Mastercard, American Express\n• Debit cards\n• PayPal\n• Apple Pay\n• Google Pay\n\n**Security:**\n• All payments processed via Stripe\n• 256-bit SSL encryption\n• Your card details are never stored\n• PCI DSS compliant',
      category: 'payments'
    },
    {
      id: '5',
      question: `How do I become a ${ccpSingularLower()}?`,
      answer: `**Become a ${CCP.singularShort}:**\n\n**Requirements:**\n• Valid UK driving license\n• Valid car insurance\n• DBS check\n• Vehicle in good condition\n• Smartphone with GPS\n\n**Application Process:**\n1. Download app and select "Join as ${CCP.singularShort}"\n2. Complete profile information\n3. Upload required documents\n4. Background check (5-7 business days)\n5. Account verification\n\n**Timeline:** Verification typically takes 3-5 business days.\n\n**Earnings:** Set your own schedule, competitive rates, weekly payments.`,
      category: 'valeter'
    },
    {
      id: '6',
      question: 'What if I\'m not satisfied with the service?',
      answer: '**Service Quality Guarantee:**\n\n**If you\'re not satisfied:**\n1. Contact us within 24 hours of service\n2. Include photos if applicable\n3. Provide booking ID and details\n4. Describe the issue clearly\n\n**We may offer:**\n• Full or partial refund\n• Free re-service\n• Account credit\n• Discount on next booking\n\n**Resolution Timeline:**\n• Response within 24 hours\n• Investigation within 48 hours\n• Resolution within 72 hours',
      category: 'quality'
    },
    {
      id: '7',
      question: 'How do rewards and points work?',
      answer: `**Rewards & Loyalty Program:**\n\n**Earn Points:**\n• 10 points per £1 spent on bookings\n• 5 points for rating ${CCP.pluralShort}\n• 50 points per friend referral\n• Bonus points during promotions\n\n**Tier Levels:**\n• **Bronze:** 0-500 points (5% discount)\n• **Silver:** 501-1,500 points (10% discount)\n• **Gold:** 1,501-3,000 points (15% discount)\n• **Platinum:** 3,000+ points (20% discount + exclusive perks)\n\n**Redeem For:**\n• Discounts on services\n• Free washes\n• Exclusive rewards\n• Priority booking\n\n**Check your tier:** Go to Rewards section on your dashboard`,
      category: 'rewards'
    },
    {
      id: '8',
      question: 'Is my data secure?',
      answer: `🔒 **Data Security & Privacy:**\n\n**Security Measures:**\n• 256-bit SSL encryption\n• Secure payment processing (Stripe)\n• PCI DSS compliant\n• Regular security audits\n\n**Privacy:**\n• GDPR compliant\n• We never share your data with third parties\n• Your location is only shared with your assigned ${ccpSingularLower()}\n• You control your privacy settings\n• Data deletion available on request\n\n**Your Rights:**\n• Access your data anytime\n• Request data deletion\n• Update preferences\n• Opt-out of marketing`,
      category: 'security'
    },
    {
      id: '9',
      question: 'How do I report an issue?',
      answer: `**Reporting Issues:**\n\n**How to Report:**\n1. Go to Help & Support\n2. Tap "Report an Issue"\n3. Select issue type\n4. Provide details:\n   - Booking ID (if applicable)\n   - Description of issue\n   - Photos (if relevant)\n\n**Response Times:**\n• Urgent issues: Within 24 hours\n• General issues: Within 48 hours\n\n**Resolution:**\n• Investigation within 48 hours\n• Resolution within 72 hours\n\n**Contact:** Email ${SUPPORT_EMAIL}`,
      category: 'support'
    },
    {
      id: '10',
      question: 'What are the service areas?',
      answer: MOBILE_SERVICE_ONLY_LAUNCH
        ? `🗺️ **Service Coverage:**\n\n**Current Service Areas:**\n• London (Greater London)\n• Manchester\n• Birmingham\n• Leeds\n• Liverpool\n• Surrounding areas\n\n**How to Check:**\n• Enter your postcode in the app\n• View available ${ccpPluralLower()} in your area\n• See estimated wait times\n• Check service availability\n\n**Expanding:**\nWe're constantly expanding to new areas. Check the app regularly for updates!`
        : `🗺️ **Service Coverage:**\n\n**Current Service Areas:**\n• London (Greater London)\n• Manchester\n• Birmingham\n• Leeds\n• Liverpool\n• Surrounding areas\n\n**How to Check:**\n• Enter your postcode in the app\n• View available ${ccpPluralLower()} in your area\n• See estimated wait times\n• Check service availability\n\n**Expanding:**\nWe're constantly expanding to new areas. Check the app regularly for updates!\n\n**Physical Locations:**\nWe also have physical car wash locations. Check the map for nearest locations.`,
      category: 'coverage'
    },
    {
      id: '11',
      question: 'How do I change my booking?',
      answer: `**Modifying Bookings:**\n\n**What You Can Change:**\n• Service type (upgrade/downgrade)\n• Location (before your ${ccpSingularLower()} accepts)\n• Time (if scheduled)\n• Vehicle (if multiple saved)\n\n**Time Limits:**\n• Mobile: Can change before your ${ccpSingularLower()} accepts\n• Scheduled: Modify up to 1 hour before\n• After your ${ccpSingularLower()} accepts: Contact support\n\n**How to Modify:**\n1. Go to Active Bookings\n2. Select booking to modify\n3. Tap "Edit Booking"\n4. Make changes\n5. Confirm updates\n\n**Cancellations:**\nFollow our refund policy (see Cancellation Policy FAQ)`,
      category: 'booking'
    },
    {
      id: '12',
      question: `What if my ${ccpSingularLower()} doesn't show up?`,
      answer: `🚨 **${CCP.singularShort} no-show policy:**\n\n**If your ${ccpSingularLower()} doesn't arrive:**\n• Wait 15 minutes past scheduled time\n• Contact us immediately via email\n• We'll find you another ${ccpSingularLower()}\n• Or provide full refund + compensation\n\n**What We Do:**\n• Immediately assign a new ${ccpSingularLower()}\n• Priority booking for you\n• Full refund if no replacement\n• Compensation for inconvenience\n\n**Compensation:**\n• Account credit\n• Discount on next booking\n• Free service upgrade\n\n**Response Time:**\n• Within 24 hours of contact\n• New ${ccpSingularLower()} assigned within 48 hours\n• Full resolution within 72 hours`,
      category: 'service'
    },
    {
      id: '13',
      question: 'How do I update my profile?',
      answer: `**Updating Your Profile:**\n\n**What You Can Update:**\n• Name and contact information\n• Email address\n• Phone number\n• Profile picture\n• Vehicle information\n• Payment methods\n• Notification preferences\n\n**How to Update:**\n1. Go to Profile section\n2. Tap "Edit Profile"\n3. Make your changes\n4. Save updates\n\n**For ${CCP.pluralShort}:**\n• Update documents\n• Change availability\n• Update vehicle info\n• Modify service areas`,
      category: 'account'
    },
    {
      id: '14',
      question: 'How do I contact support?',
      answer: `📧 **Contact Support:**\n\n**Email Support:**\n• ${SUPPORT_EMAIL}\n• General inquiries\n• Response within 24 hours\n• Include booking ID if applicable\n\n**Response Times:**\n• General inquiries: Within 24 hours\n• Urgent issues: Within 12 hours\n• Non-urgent: Within 48 hours`,
      category: 'support'
    }
  ];

  const toggleFAQ = async (id: string) => {
    try {
      await hapticFeedback('light');
      setExpandedFAQ(expandedFAQ === id ? null : id);
    } catch (error) {
      console.error('Error in toggleFAQ:', error);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <AppHeader
        title="Help & Support"
        subtitle="Priority answers and contact options"
        accountType="customer"
        showBack
        fullWidth
        onBack={() => { hapticFeedback('light'); router.back(); }}
      />

      <ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: CONTENT_PADDING_H, ...scrollPad }}
      >

        {/* Email Support */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Contact Support</Text>
            <Text style={styles.sectionSubtitle}>Get help via email</Text>
          </View>
          <TouchableOpacity 
            style={styles.emailSupportCard} 
            onPress={() => Linking.openURL(`mailto:${SUPPORT_EMAIL}?subject=Support Request`)}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={['rgba(135, 206, 235, 0.2)', 'rgba(30, 58, 138, 0.25)']}
              style={styles.emailSupportGradient}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <View style={styles.emailSupportIconWrapper}>
                <GradientIconBox icon="mail" preset="sky" boxSize={56} size={30} borderRadius={16} elevated />
              </View>
              <Text style={styles.emailSupportTitle}>Email Support</Text>
              <Text style={styles.emailSupportSubtitle}>{SUPPORT_EMAIL}</Text>
              <Text style={styles.emailSupportDescription}>Send us an email and we'll get back to you within 24 hours</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* FAQ Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Frequently Asked Questions</Text>
          <View style={styles.faqContainer}>
            {faqs.map((faq) => (
              <TouchableOpacity
                key={faq.id}
                style={styles.faqItem}
                onPress={() => toggleFAQ(faq.id)}
              >
                <View style={styles.faqHeader}>
                  <Text style={styles.faqQuestion}>{faq.question}</Text>
                  <Text style={styles.faqToggle}>
                    {expandedFAQ === faq.id ? '−' : '+'}
                  </Text>
                </View>
                {expandedFAQ === faq.id && (
                  <Text style={styles.faqAnswer}>{faq.answer}</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </View>


        {/* Legal Links */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Legal</Text>
          <View style={styles.legalGrid}>
            <TouchableOpacity style={styles.legalLink} onPress={() => void Linking.openURL(POLICY_URL)}>
              <Text style={styles.legalLinkText}>Terms and conditions</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.legalLink} onPress={() => void Linking.openURL(POLICY_URL)}>
              <Text style={styles.legalLinkText}>Privacy policy</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.legalLink} onPress={() => void Linking.openURL(POLICY_URL)}>
              <Text style={styles.legalLinkText}>Cookie policy</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* App Info */}
        <View style={styles.appInfoCard}>
          <Text style={styles.appInfoTitle}>Wish a Wash</Text>
          <Text style={styles.appInfoVersion}>Version 1.0.0</Text>
          <Text style={styles.appInfoCopyright}>© 2025 Wish a Wash. All rights reserved.</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  scrollView: {
    flex: 1,
  },
  section: {
    padding: 20,
    marginBottom: SECTION_GAP,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  quickAction: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  quickActionIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  quickActionTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 4,
  },
  quickActionSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  contactGrid: {
    gap: 12,
  },
  contactOption: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  contactIcon: {
    fontSize: 24,
    marginRight: 16,
  },
  contactInfo: {
    flex: 1,
  },
  contactTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
  contactSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
  },
  faqContainer: {
    gap: 12,
  },
  faqItem: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.16)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 6,
    elevation: 2,
  },
  faqHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  faqQuestion: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    flex: 1,
    marginRight: 16,
  },
  faqToggle: {
    color: '#87CEEB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  faqAnswer: {
    color: '#E5E7EB',
    fontSize: 14,
    lineHeight: 20,
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
  troubleshootingCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  troubleshootingTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  issueItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  issueIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  issueInfo: {
    flex: 1,
  },
  issueTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 2,
  },
  issueDescription: {
    color: '#87CEEB',
    fontSize: 12,
    lineHeight: 16,
  },
  legalGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  legalLink: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.2)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 2,
  },
  legalLinkText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  appInfoCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    marginHorizontal: isSmallScreen ? 16 : 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  appInfoTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  appInfoVersion: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 4,
  },
  appInfoCopyright: {
    color: '#9CA3AF',
    fontSize: 10,
    textAlign: 'center',
  },
  // Chat styles
  chatOptionsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  chatOption: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  chatOptionIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  chatOptionTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 4,
  },
  chatOptionSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  chatContainer: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#60A5FA',
    backgroundColor: '#60A5FA',
  },
  chatBackButton: {
    padding: 8,
  },
  chatBackButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  chatTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  chatMessages: {
    flex: 1,
    padding: 16,
  },
  messageContainer: {
    marginBottom: 12,
    maxWidth: '80%',
  },
  userMessage: {
    alignSelf: 'flex-end',
    backgroundColor: '#87CEEB',
    borderRadius: 16,
    padding: 12,
    borderBottomRightRadius: 4,
  },
  agentMessage: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 12,
    borderBottomLeftRadius: 4,
  },
  aiMessage: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    borderRadius: 16,
    padding: 12,
    borderBottomLeftRadius: 4,
  },
  messageText: {
    fontSize: 14,
    lineHeight: 20,
  },
  userMessageText: {
    color: '#0A1929',
    fontWeight: '500',
  },
  agentMessageText: {
    color: '#F9FAFB',
  },
  aiMessageText: {
    color: '#F9FAFB',
  },
  messageTime: {
    fontSize: 10,
    color: '#9CA3AF',
    marginTop: 4,
    alignSelf: 'flex-end',
  },
  typingIndicator: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 12,
    borderBottomLeftRadius: 4,
  },
  typingText: {
    color: '#87CEEB',
    fontSize: 12,
    fontStyle: 'italic',
  },
  chatInputContainer: {
    flexDirection: 'row',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    backgroundColor: 'rgba(255, 255, 255, 0.02)',
  },
  chatInput: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    color: '#F9FAFB',
    fontSize: 14,
    marginRight: 8,
    maxHeight: 100,
  },
  sendButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  quickRepliesContainer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#60A5FA',
    backgroundColor: '#60A5FA',
  },
  quickReplyButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 8,
    marginRight: 8,
  },
  quickReplyText: {
    color: '#F9FAFB',
    fontSize: 14,
  },

  // Modern Styles
  sectionHeader: {
    marginBottom: 16,
  },
  sectionSubtitle: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '500',
    marginTop: 4,
    opacity: 0.9,
  },
  
  // Modern Chat Options
  modernChatOption: {
    flex: 1,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(255, 255, 255, 0.12)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  modernChatOptionGradient: {
    padding: 20,
    alignItems: 'center',
    minHeight: 140,
  },
  modernChatIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  modernChatIcon: {
    fontSize: 28,
  },
  modernChatTitle: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 6,
    textAlign: 'center',
  },
  modernChatSubtitle: {
    color: '#E5E7EB',
    fontSize: 13,
    fontWeight: '500',
    textAlign: 'center',
    marginBottom: 8,
    opacity: 0.9,
  },
  modernChatBadge: {
    color: ACCENT,
    fontSize: 11,
    fontWeight: '700',
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    overflow: 'hidden',
  },
  
  // Modern Quick Actions
  modernQuickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  modernQuickAction: {
    width: '48%',
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(255, 255, 255, 0.12)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  modernQuickActionGradient: {
    padding: 18,
    alignItems: 'center',
    minHeight: 120,
  },
  modernQuickActionIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  modernQuickActionIcon: {
    fontSize: 24,
  },
  modernQuickActionTitle: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 4,
  },
  modernQuickActionSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
    opacity: 0.9,
  },
  
  // Modern AI Chat Modal
  modernChatContainer: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  modernChatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    paddingTop: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  modernChatBackButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
  },
  modernChatBackButtonGradient: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modernChatBackButtonText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
  },
  modernChatHeaderContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
    marginLeft: 12,
  },
  modernChatHeaderIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(16, 185, 129, 0.3)',
  },
  modernChatHeaderEmoji: {
    fontSize: 22,
  },
  modernChatHeaderSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '500',
    marginTop: 2,
  },
  modernChatHeaderSpacer: {
    width: 40,
  },
  modernChatMessages: {
    flex: 1,
  },
  modernChatMessagesContent: {
    padding: 16,
    paddingBottom: 20,
  },
  modernMessageContainer: {
    flexDirection: 'row',
    marginBottom: 16,
    alignItems: 'flex-end',
    gap: 8,
  },
  modernUserMessage: {
    justifyContent: 'flex-end',
  },
  modernAiMessage: {
    justifyContent: 'flex-start',
  },
  modernMessageBubble: {
    maxWidth: '75%',
    borderRadius: 20,
    padding: 14,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  modernMessageText: {
    fontSize: 15,
    lineHeight: 20,
    fontWeight: '500',
  },
  modernUserMessageText: {
    color: '#FFFFFF',
  },
  modernAiMessageText: {
    color: '#F9FAFB',
  },
  modernMessageTime: {
    fontSize: 10,
    color: 'rgba(255, 255, 255, 0.6)',
    marginTop: 6,
    fontWeight: '500',
  },
  modernAiAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(16, 185, 129, 0.3)',
  },
  modernAiAvatarText: {
    color: ACCENT,
    fontSize: 11,
    fontWeight: '800',
  },
  modernUserAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  modernUserAvatarText: {
    color: SKY,
    fontSize: 11,
    fontWeight: '800',
  },
  modernTypingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  modernTypingDots: {
    flexDirection: 'row',
    gap: 4,
  },
  modernTypingDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: SKY,
    opacity: 0.6,
  },
  modernTypingText: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '500',
    fontStyle: 'italic',
  },
  modernQuickRepliesContainer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
  },
  modernQuickRepliesTitle: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  modernQuickRepliesScroll: {
    gap: 10,
  },
  modernQuickReplyButton: {
    borderRadius: 20,
    overflow: 'hidden',
    marginRight: 10,
  },
  modernQuickReplyGradient: {
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  modernQuickReplyText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '600',
  },
  modernChatInputContainer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    backgroundColor: 'rgba(255, 255, 255, 0.02)',
  },
  modernChatInputWrapper: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
  },
  modernChatInput: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 24,
    paddingHorizontal: 18,
    paddingVertical: 12,
    color: '#F9FAFB',
    fontSize: 15,
    maxHeight: 100,
    borderWidth: 1.5,
    borderColor: 'rgba(255, 255, 255, 0.12)',
  },
  modernSendButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    overflow: 'hidden',
  },
  modernSendButtonDisabled: {
    opacity: 0.5,
  },
  modernSendButtonGradient: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modernSendButtonIcon: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
  },
  modernWhatsAppButton: {
    marginTop: 12,
    marginBottom: 8,
    borderRadius: 20,
    overflow: 'hidden',
    alignSelf: 'flex-start',
  },
  modernWhatsAppButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    gap: 8,
  },
  modernWhatsAppButtonIcon: {
    fontSize: 18,
  },
  modernWhatsAppButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
  emailSupportCard: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135, 206, 235, 0.3)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  emailSupportGradient: {
    padding: 24,
    alignItems: 'center',
  },
  emailSupportIconWrapper: {
    marginBottom: 16,
    alignItems: 'center',
  },
  emailSupportTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
    textAlign: 'center',
  },
  emailSupportSubtitle: {
    color: SKY,
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 12,
    textAlign: 'center',
  },
  emailSupportDescription: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});
