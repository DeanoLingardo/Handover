// Deep link target for waw://reset-password (what the https landing page forwards recovery links to).
// The screen itself lives in app/auth/reset-password.tsx so /auth/reset-password works as well.
export { default } from './auth/reset-password';
