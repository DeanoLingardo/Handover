# Auth e-mail fix – customer app (Wish a Wash, scheme `waw`)
Built on WishaWash-fixed-live-LIVE (Stripe LIVE changes untouched; no fallback test key). Patch: `auth-fix.patch`.

| File | Why |
|---|---|
| `src/lib/authLinks.ts` (new) | Per-app redirect builder (`EXPO_PUBLIC_AUTH_REDIRECT_BASE` + `/customer`, deep-link fallback if unset), parser for ?code / ?token_hash&type / #access_token fragments, session establishment (verifyOtp / setSession / exchangeCodeForSession, de-duplicated), duplicate-sign-up detector |
| `src/providers/enhanced-auth-context.tsx` | signUp sends `emailRedirectTo` + `data.app='customer'` (userType etc. kept); resetPasswordForEmail uses the per-app redirect instead of `waw://reset-password`; duplicate e-mail (empty `identities`) throws "This email is already registered; please sign in or use another email"; OAuth completion now uses the shared link handler (also supports fragment tokens) |
| `app/auth/callback.tsx` | Handles code, token_hash+type and fragment tokens; recovery links are forwarded to the reset screen; shows an error + "Back to sign in" on failure |
| `app/auth/reset-password.tsx` (new) | The missing "choose a new password" screen: consumes the recovery link/session, calls `updateUser({password})`, signs out, back to login |
| `app/reset-password.tsx` (new) | Route alias so the deep link `waw://reset-password` works |
| `app/components/NavigationTab.tsx` | Hide the bottom tab bar on `/reset-password` |
| `env.example` | Pointed at the wrong Supabase project (cbtnhqbfmdavtcbjqepv + its anon key); now `rmhlnfqgjipeawaddwor` placeholders, no keys; documents `EXPO_PUBLIC_AUTH_REDIRECT_BASE` |
| `src/lib/__tests__/authLinks.test.ts` (new) | Unit tests for the link helpers (8 tests) |
| `tsconfig.json` | Exclude `src/**/__tests__` from the app type-check (no @types/jest in the project) |
